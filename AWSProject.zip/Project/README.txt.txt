Student name: Mbachu Valentine
Cohort: Cloud DevOps
Project:Deploy Static Website on AWS
Wesite endpoint: http://projectbucket26.s3-website-us-east-1.amazonaws.com
Amazon resource name: arn:aws:s3:::projectbucket26
cloudfont distribution domain name: https://d29bm3h6uja7wa.cloudfront.net
ARN: arn:aws:cloudfront::418181897115:distribution/E13QSQAFNFR0HF
 



